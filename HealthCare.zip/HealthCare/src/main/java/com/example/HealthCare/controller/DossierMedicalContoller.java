package com.example.HealthCare.controller;

import com.example.HealthCare.dto.DossierMedicalRequestDto;
import com.example.HealthCare.dto.DossierMedicalResponseDto;
import com.example.HealthCare.service.DossierMedicalService;
import io.swagger.v3.oas.annotations.Operation;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/dossier")
@RequiredArgsConstructor
public class DossierMedicalContoller {
    private final DossierMedicalService dossierMedicalService;

    @PostMapping
    @Operation(summary = "Creation dossier medical")
    public DossierMedicalResponseDto createDossier(@Valid @RequestBody DossierMedicalRequestDto requestDto){
        return dossierMedicalService.createDossier(requestDto);
    }
    @PutMapping("/{id}/diagnostic")
    @Operation(summary = "Ajouter diagnostic")
    public  DossierMedicalResponseDto addDiagnostic(@PathVariable Long id,@Valid @RequestBody String diagnostic){

        return dossierMedicalService.ajouterDiagnostic(id,diagnostic);
    }

    @PutMapping("/{id}/observation")
    @Operation(summary = "Ajouter observation")
    public  DossierMedicalResponseDto addObservation(@PathVariable Long id,@Valid @RequestBody String observation){
        return dossierMedicalService.ajouterObeservation(id,observation);
    }
    @GetMapping("/{id}")
    @Operation(summary = "Consulter dossier")
    public DossierMedicalResponseDto getDossierMedicalById(@PathVariable Long id ){
        return dossierMedicalService.findDossierMedicalById(id);
    }
}
