package com.example.HealthCare.service;

import com.example.HealthCare.dto.DossierMedicalResponseDto;
import com.example.HealthCare.dto.RendezVouRequestDTO;
import com.example.HealthCare.dto.RendezVousResponseDTO;
import com.example.HealthCare.entity.Medecin;
import com.example.HealthCare.entity.Patient;
import com.example.HealthCare.entity.RendezVous;
import com.example.HealthCare.entity.StatutRendezVous;
import com.example.HealthCare.mapper.RendezVousMapper;
import com.example.HealthCare.repository.MedecinRepo;
import com.example.HealthCare.repository.PatientRepo;
import com.example.HealthCare.repository.RendezVousRepo;
import jakarta.transaction.Status;
import jakarta.transaction.Transactional;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;

@Service
public class RendezVousService {
    private final RendezVousRepo rendezVousRepo;
    private final RendezVousMapper rendezVousMapper;
    private final PatientRepo patientRepo;
    private final MedecinRepo  medecinRepo;

    public RendezVousService(RendezVousRepo rendezVousRepo, RendezVousMapper rendezVousMapper, PatientRepo patientRepo, MedecinRepo medecinRepo) {
        this.rendezVousRepo = rendezVousRepo;
        this.rendezVousMapper = rendezVousMapper;
        this.patientRepo = patientRepo;
        this.medecinRepo = medecinRepo;
    }

    @Transactional
    public RendezVousResponseDTO createRendezVous(RendezVouRequestDTO  rendezVouRequestDTO) {
        RendezVous createRendezVous= rendezVousMapper.toEntity(rendezVouRequestDTO);

            Patient patient= patientRepo.findById(rendezVouRequestDTO.getPatientId()).orElseThrow(()->new RuntimeException("Patient Not Found"));
            createRendezVous.setPatient(patient);

            Medecin medecin= medecinRepo.findById(rendezVouRequestDTO.getMedecinId()).orElseThrow(()->new RuntimeException("Medecin Not Found"));
            createRendezVous.setMedecin(medecin);
        if(createRendezVous.getStatut()==null){
            createRendezVous.setStatut(StatutRendezVous.PLANIFIE);
        }
        RendezVous saveRendezVous= rendezVousRepo.save(createRendezVous);
        return rendezVousMapper.toDto(saveRendezVous);
    }

    @Transactional
    public RendezVousResponseDTO updateRendezVous(Long id, RendezVouRequestDTO requestDTO){
        RendezVous rendezVous =rendezVousRepo.findById(id).orElseThrow(()->new RuntimeException("RendezVous Not Found"));
       Patient patient= patientRepo.findById(requestDTO.getPatientId()).orElseThrow(()->new RuntimeException("Patient Not Found"));
       Medecin medecin= medecinRepo.findById(requestDTO.getMedecinId()).orElseThrow(()->new RuntimeException("Medecin Not Found"));

//        rendezVous.setDateRendezVous(requestDTO.getDateRendezVous());
//
//        if(requestDTO.getStatut()!=null){
//            rendezVous.setStatut(requestDTO.getStatut());
//        }
        rendezVousMapper.update(requestDTO,rendezVous);
        rendezVous.setPatient(patient);
        rendezVous.setMedecin(medecin);
        RendezVous updateRendez= rendezVousRepo.save(rendezVous);
        return rendezVousMapper.toDto(updateRendez);
    }

    @Transactional
    public Page<RendezVousResponseDTO> getAllRendezVous(int page, int size, String sortBy){
        Pageable pageable= PageRequest.of(page,size, Sort.by(sortBy).ascending());

      Page<RendezVous> rendezVousList=rendezVousRepo.findAll(pageable);
      return  rendezVousList.map(rendezVousMapper::toDto);
    }
    @Transactional
    public List<RendezVousResponseDTO> rechercheRendezVousPatient(Long patientId){
        List<RendezVous>listOfPatient=rendezVousRepo.findByPatientId(patientId);
        return rendezVousMapper.toDto(listOfPatient);
    }

    @Transactional
    public List<RendezVousResponseDTO> rechercheRendezVousMedecin(Long medecinId){
        List<RendezVous> listOfMedecin=rendezVousRepo.findByMedecinId(medecinId);
        return rendezVousMapper.toDto(listOfMedecin);
    }

    @Transactional
    public RendezVousResponseDTO annulerRendezVous(Long id){
        RendezVous rendezVous= rendezVousRepo.findById(id).orElseThrow(()->new RuntimeException("RendezVous Not Found"));
        rendezVous.setStatut(StatutRendezVous.ANNULE);
        rendezVousRepo.save(rendezVous);;
        return rendezVousMapper.toDto(rendezVous);
    }

//    @Transactional
//    public Page<RendezVousResponseDTO> getRendezVousByStatu( Long medecin_id,StatutRendezVous statut,Pageable  pageable){
//        Medecin medecin =medecinRepo.findById(medecin_id).orElseThrow(()->new RuntimeException("not found"));
//       return  rendezVousRepo.findByStatut(statut,medecin_id,pageable)
//               .map(rendezVousMapper::toDto);
//    }
    @Transactional
    public Page<RendezVousResponseDTO> searchByStatus(
            StatutRendezVous status,
            int page,
            int size
    ) {
        Pageable pageable = PageRequest.of(page, size);

        return rendezVousRepo.findByStatut(status, pageable)
                .map(rendezVousMapper::toDto);
    }


     //patient
    @Transactional
    public List<RendezVousResponseDTO> getMyRendezVous(){
        String email= SecurityContextHolder
                .getContext()
                .getAuthentication()
                .getName();

        Patient patient= patientRepo.findByEmail(email).orElseThrow(()->new RuntimeException("Not found"));

        List<RendezVous> list= rendezVousRepo.findByPatientId(patient.getId());
        return  list.stream().map(rendezVousMapper::toDto).toList();
    }

    public List<RendezVousResponseDTO> getMyRendezVousMedecin() {

        String email = SecurityContextHolder.getContext()
                .getAuthentication()
                .getName();

        Medecin medecin = medecinRepo.findByEmail(email)
                .orElseThrow(() -> new RuntimeException("Medecin not found"));

        List<RendezVous> list = rendezVousRepo.findByMedecinId(medecin.getId());

        return list.stream()
                .map(rdv -> new RendezVousResponseDTO(
                        rdv.getId(),
                        rdv.getDateRendezVous(),
                        rdv.getStatut(),
                        rdv.getPatient().getId(),
                        rdv.getMedecin().getId()
                ))
                .toList();
    }




}
