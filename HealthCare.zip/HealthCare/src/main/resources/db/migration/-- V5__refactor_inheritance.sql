

-- 1. Drop old FK constraints that reference patient/medecin id directly
ALTER TABLE rendez_vous DROP FOREIGN KEY fk_rdv_patient;
ALTER TABLE rendez_vous DROP FOREIGN KEY fk_rdv_medecin;
ALTER TABLE dossier_medical DROP FOREIGN KEY fk_dossier_patient;

-- 2. Add dtype discriminator column to user table
ALTER TABLE user ADD COLUMN dtype VARCHAR(31) NOT NULL DEFAULT 'User';

-- 3. Restructure patient table: replace auto-increment id with FK to user
ALTER TABLE patient DROP PRIMARY KEY;
ALTER TABLE patient DROP COLUMN id;
ALTER TABLE patient DROP COLUMN email;  -- now inherited from user
ALTER TABLE patient ADD COLUMN id BIGINT PRIMARY KEY;
ALTER TABLE patient ADD CONSTRAINT fk_patient_user FOREIGN KEY (id) REFERENCES user(id);

-- 4. Restructure medecin table: replace auto-increment id with FK to user
ALTER TABLE medecin DROP PRIMARY KEY;
ALTER TABLE medecin DROP COLUMN id;
ALTER TABLE medecin DROP COLUMN email;  -- now inherited from user
ALTER TABLE medecin ADD COLUMN id BIGINT PRIMARY KEY;
ALTER TABLE medecin ADD CONSTRAINT fk_medecin_user FOREIGN KEY (id) REFERENCES user(id);

-- 5. Re-add FK constraints
ALTER TABLE rendez_vous ADD CONSTRAINT fk_rdv_patient FOREIGN KEY (patient_id) REFERENCES patient(id);
ALTER TABLE rendez_vous ADD CONSTRAINT fk_rdv_medecin FOREIGN KEY (medecin_id) REFERENCES medecin(id);
ALTER TABLE dossier_medical ADD CONSTRAINT fk_dossier_patient FOREIGN KEY (patient_id) REFERENCES patient(id);